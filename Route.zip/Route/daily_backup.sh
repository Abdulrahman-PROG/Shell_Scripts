#!/bin/bash
# Script to automate daily backups of /home and send alerts on failure

SOURCE_DIR="/home"
BACKUP_DIR="/var/backups"
TIMESTAMP=$(date '+%Y-%m-%d_%H-%M-%S')
BACKUP_FILE="$BACKUP_DIR/home_backup_$TIMESTAMP.tar.gz"
LOG_FILE="/var/log/daily_backup.log"

# Create the backup directory if it doesn't exist
if [ ! -d "$BACKUP_DIR" ]; then
    mkdir -p "$BACKUP_DIR"
fi

# Perform the backup
echo "$(date '+%Y-%m-%d %H:%M:%S') - Starting backup of $SOURCE_DIR" >> "$LOG_FILE"
if tar -czf "$BACKUP_FILE" "$SOURCE_DIR" 2>>"$LOG_FILE"; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') - Backup completed successfully" >> "$LOG_FILE"
else
    echo "$(date '+%Y-%m-%d %H:%M:%S') - Backup failed" >> "$LOG_FILE"
    echo "Backup of $SOURCE_DIR failed at $(date)" | mail -s "Backup Failure Alert" abdulrahman.yasser.elbanna@gmail.com
fi